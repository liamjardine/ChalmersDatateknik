The cabal-install package
=========================

See the [Cabal web site] for more information.

The `cabal-install` package provides a command line tool named `cabal`.
It uses the [Cabal] library and provides a user interface to the
Cabal/[Hackage] build automation and package management system. It can
build and install both local and remote packages, including
dependencies.

[Cabal web site]: http://www.haskell.org/cabal/
[Cabal]: ../Cabal/README.md
